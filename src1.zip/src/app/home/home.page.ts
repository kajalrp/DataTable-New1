import { Component, ViewChild} from '@angular/core';
import { ColumnMode, SelectionType } from '@swimlane/ngx-datatable';
import { DatatableComponent } from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

public pepperoni = true;
public sausage = true;
public mushrooms = true;
public toogle = true;

selected = [];
temp = [];
editing = {};

reorderable = true;
selectedTheme: 'string';


columns = [{ prop: 'UserID' }, { name: 'FirstName' }, { name: 'LastName' }, { name: 'EmailID' }];

@ViewChild(DatatableComponent, { static: false }) table: DatatableComponent;

  SelectionType = SelectionType;


  rows = [
    {
   userId: 1,
   firstName: 'Priya',
   lastName: 'Kochar',
   emailId: 'pkochar100@gmail.com',
   gender: 'Female',
   age: 24,
   state: 'Maharashtra',
   address: 'Ytl',
   city: 'ytl',
   contactNo: 898877665,
    },
    {
   userId: 2,
   firstName: 'Ankita',
   lastName: 'Shende',
   emailId: 'ankita100@gmail.com'
   },
   {
   userId: 3,
   firstName: 'Prajakta',
   lastName: 'Joshi',
   emailId: 'prajakta@gmail.com'
   },
   {
    userId: 4,
    firstName: 'Smita',
    lastName: 'Jain',
    emailId: 'smita@gmail.com'
    },
    {
      userId: 5,
      firstName: 'Sukirti',
      lastName: 'Singh',
      emailId: 'sukirti@gmail.com'
      },
      {
      userId: 6,
      firstName: 'Deepak',
      lastName: 'Shinde',
      emailId: 'deepak@gmail.com'
      },
      {
      userId: 7,
      firstName: 'Sam',
      lastName: 'Joshi',
      emailId: 'sam@gmail.com'
      },
      {
      userId: 8,
      firstName: 'Rani',
      lastName: 'Rajurkar',
      emailId: 'rani@gmail.com'
      },
      

  ];

  tablestyle = 'bootstrap';

  constructor() {
    this.fetch(data => {
      // cache our list
      this.temp = [...data];

      // push our inital complete list
      this.rows = data;
    });
  }

  fetch(cb) {
    const req = new XMLHttpRequest();
    req.open('GET', `assets/data/company.json`);

    req.onload = () => {
      cb(JSON.parse(req.response));
    };

    req.send();
  }

  onSelect({ selected }) {
    console.log('Select Event', selected, this.selected);

    this.selected.splice(0, this.selected.length);
    this.selected.push(...selected);
  }

  onActivate(event) {
    console.log('Activate Event', event);
  }

  displayCheck(row) {
    return row.firstName !== 'Ethel Price';
  }

  switchStyle(){
    // tslint:disable-next-line: triple-equals
    if (this.tablestyle == 'dark') {
      this.tablestyle = 'bootstrap';
    } else {
      this.tablestyle = 'dark';
    }
  }

  temp2 = this.rows;

   updateFilter(event) {
   const val = event.target.value.toLowerCase();
   this.rows = [...this.temp2]; // and here you have to initialize it with your data
   this.temp = [...this.rows];
    // filter our data
   // tslint:disable-next-line: only-arrow-functions
   const temp = this.rows.filter(function(d) {
      return d.firstName.toLowerCase().indexOf(val) !== -1 || !val;
    });
   const temp1 = this.rows.filter(function(d) {
      return d.lastName.toLowerCase().indexOf(val) !== -1 || !val;
    });
   const temp2 = this.rows.filter(function(d) {
      return d.emailId.toLowerCase().indexOf(val) !== -1 || !val;
    });
    // update the rows
   this.rows = temp;
   this.rows = temp1;
   this.rows = temp2;
    // Whenever the filter changes, always go back to the first page
   this.table.offset = 0;
 }

 getRowClass = (row) => {
  return {
    'row-color': true
  };
}

public deleteObject(objectIndex) {
  this.rows = this.rows.filter( (item, index) => {
    if (index !== objectIndex) return true;
  })
}

public addObject() {
  this.rows.push({ userId: 12 , firstName: '' , lastName: '' , emailId: ''});
  this.rows = [...this.rows]
}

updateValue(event, cell, rowIndex) {
  console.log('inline editing rowIndex', rowIndex);
  this.editing[rowIndex + '-' + cell] = false;
  this.rows[rowIndex][cell] = event.target.value;
  this.rows = [...this.rows];
  console.log('UPDATED!', this.rows[rowIndex][cell]);
}



}
